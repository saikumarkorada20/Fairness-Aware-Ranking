def swap(dict, pos1, pos2): 
    dict[pos1], dict[pos2] = dict[pos2], dict[pos1] 
    return dict